@extends('frontend.layouts.master')

@section('title','About us')

@section('main-content')
    <h2>About us </h2>
    <div class="">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus eum laboriosam dolor illum nobis!</p>
    </div>
@endsection

