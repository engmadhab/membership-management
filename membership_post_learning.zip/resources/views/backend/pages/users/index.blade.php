@extends('backend.layouts.master')

@section('title', 'User Lists | Admin Panel')

@section('admin-maincontent')
    <h3>user list</h3>
@endsection
