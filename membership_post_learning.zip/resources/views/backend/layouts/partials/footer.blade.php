<footer>
            <div class="footer-area">
                <p>© Copyright 2022. All right reserved. Design & Develop by <a href="https:4axistech.com">4Axis Technology</a>.</p>
            </div>
        </footer>