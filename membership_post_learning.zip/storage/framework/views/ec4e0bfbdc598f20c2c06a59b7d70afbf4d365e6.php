

<?php $__env->startSection('main-content'); ?>
    <div>
        <?php echo e($category->name); ?>

    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('end-content'); ?>
    <p>dynamic end content from test file</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\membership\resources\views/frontend/payges/categories/show.blade.php ENDPATH**/ ?>