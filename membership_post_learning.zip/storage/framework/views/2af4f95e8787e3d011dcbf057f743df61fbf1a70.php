


<?php $__env->startSection('main-content'); ?>
    <p>dynamic Main content from test2 file</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\membership\resources\views/frontend/payges/test2.blade.php ENDPATH**/ ?>