

<?php $__env->startSection('title', 'User Lists | Admin Panel'); ?>

<?php $__env->startSection('admin-maincontent'); ?>
    <h3>user list</h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\membership\resources\views/backend/pages/users/index.blade.php ENDPATH**/ ?>