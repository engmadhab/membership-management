

<?php $__env->startSection('styles'); ?>
    <style>
        #wrapper{
            background: red;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <p>dynamic Main content from test file</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('end-content'); ?>
    <p>dynamic end content from test file</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
    <script>
        alert('test');
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\membership\resources\views/frontend/payges/test.blade.php ENDPATH**/ ?>