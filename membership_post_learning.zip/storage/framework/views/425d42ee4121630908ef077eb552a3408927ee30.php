<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">    
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
    <div id="wrapper" class="pt-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h2 class="float-start">New tasks</h2>                            
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('tasks.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="title" class="form-label">Title</label>
                                    <input type="text" name="title" class="form-control" id="title" placeholder="Enter title">                                   
                                </div>
                                <div class="form-group">
                                    <label for="details" class="form-label">Details</label>
                                    <textarea name="details" id="details" class="form-control" rows="5" placeholder="Enter details"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="status" class="form-label">Status</label>
                                    <select name="status" id="status" class="form-control">
                                        <option value="Open">Open</option>
                                        <option value="Close">Close</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary mt-4">Submit</button>
                            </form>             
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
   
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\membership\resources\views/tasks/create.blade.php ENDPATH**/ ?>