<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> <?php echo $__env->yieldContent('title', 'Laravel Membership Management'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<div id="wrapper">
    <p>Header</p>
    <?php echo $__env->yieldContent('main-content'); ?>
    <?php echo $__env->yieldContent('end-content'); ?>
    <p>footer</p>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<?php echo $__env->yieldContent('page_scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\membership\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>