

<h1 style="text-align: center; padding-top:10%">
Laravel Membership Management</h1><?php /**PATH C:\xampp\htdocs\membership\resources\views/welcome.blade.php ENDPATH**/ ?>