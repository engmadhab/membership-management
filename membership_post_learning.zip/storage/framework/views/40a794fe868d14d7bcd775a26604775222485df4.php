<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Posts | Membership Management</title>
    <style>
        .form{

            padding: 5%;
        }
    </style>
</head>
<body>

    <form action="<?php echo e(route('posts.store')); ?>" method="POST" class="form">
        <?php echo csrf_field(); ?>
        <label for="">Post title </label>
        <input type="text" name="title" placeholder="Title"> <br/>
        <label for="">Description</label>
        <textarea name="description" id="" cols="30" rows="10"></textarea><br/>

        <button type="submit">Submit</button>
    </form>


    <h3>All post</h3>
    
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h4><?php echo e($post->title); ?></h4>
        <div>
            <?php echo $post->description; ?>

        </div>
        <a href="<?php echo e(route('posts.show', $post->slug)); ?>">View More...</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\membership\resources\views/posts/index.blade.php ENDPATH**/ ?>