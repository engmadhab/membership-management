

<?php $__env->startSection('main-content'); ?>
    <div>
        <h2><?php echo e($post->title); ?></h2>
        <?php echo $post->description; ?>

        <br>
        <hr>
        <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <mark><?php echo e($tag->name); ?>,</mark>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <h4>Comments</h4>

            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <br>                
                <p><?php echo e($comment->comment); ?></p>
                <p>-by <?php echo e($comment->user->name); ?></p>
                 <p>At - <?php echo e($comment->created_at->diffForHumans()); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\membership\resources\views/frontend/pages/posts/show.blade.php ENDPATH**/ ?>